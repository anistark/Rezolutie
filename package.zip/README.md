Rezolutie App for Firefox OS
============

New Year Resolutions list.
A simple todo app based on Todos Moz App.
